Lab: DOM XSS in jQuery anchor href attribute sink using location.search source
XSS in Feedback page.
-Uses the jQuery library's $ selector function to find an anchor element
-Changes its href attribute using data from location.search
In returnPath parameter -> javascript:alert(document.cookie)