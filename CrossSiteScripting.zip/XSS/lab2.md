Lab: Stored XSS into HTML context with nothing encoded
Task: Call alert when comment is loaded.
<script>alert(1)</script> : put it as comment of blog.