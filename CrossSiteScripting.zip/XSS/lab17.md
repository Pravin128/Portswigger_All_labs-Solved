# Lab: Reflected XSS into a JavaScript string with single quote and backslash escaped

```Shtml
    </script><script></script>
    ```