# Lab: Reflected XSS into HTML context with all tags blocked except custom ones

Task: To perform a cross-site scripting attack that injects a custom tag and automatically alerts document.cookie.
