# Lab: Reflected XSS into a JavaScript string with angle brackets and double quotes HTML-encoded and single quotes escaped

Task: To call alert() function.
    Angle brackets and double are HTML encoded and single quotes are escape

    /-alert(1)//