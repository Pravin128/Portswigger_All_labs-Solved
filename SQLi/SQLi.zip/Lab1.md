Lab: SQL injection vulnerability in WHERE clause allowing retrieval of hidden data
Vuln in product category filter
Task: Find unreleased products.

' OR 1=1--
