Lab: SQL injection vulnerability allowing login bypass
Task: login as an administrator.

administrator' 1=1--  : In the login.